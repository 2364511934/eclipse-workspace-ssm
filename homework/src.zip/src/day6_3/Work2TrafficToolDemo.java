package day6_3;

public class Work2TrafficToolDemo {

	public static void main(String[] args) {
		Work2TrafficTool work2TrafficTool = new  Work2TrafficTool(100, 300);
		
		work2TrafficTool.accelerate(200);
		work2TrafficTool.deceleration(20);
		work2TrafficTool.run();

	}

}
