package day6_3;

public class Work3StudentDemo {

	public static void main(String[] args) {
		Work3Student work3Student1 = new Work3Student("1234", "guojing", 33);
		Work3Student work3Student2 = new Work3Student("huangrong", 18);
		work3Student1.show();
		work3Student2.show();
	}

}
