package day6_2;

public class ElectricLionDemo {

	public static void main(String[] args) {
		ElectricLion electricLion = new ElectricLion("�ú���", "Ʒ��", 1223.3);
		
		electricLion.run();
		electricLion.call();
	}

}
