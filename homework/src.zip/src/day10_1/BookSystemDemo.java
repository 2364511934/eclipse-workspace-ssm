package day10_1;

import java.text.ParseException;

public class BookSystemDemo {

	public static void main(String[] args) throws ParseException {
		Runner runner = new Runner();
		runner.start();
	}

}