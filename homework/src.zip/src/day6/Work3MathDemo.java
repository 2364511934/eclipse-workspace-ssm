package day6;

public class Work3MathDemo {

	public static void main(String[] args) {
		Work3Math work3Math = new Work3Math();
		int n1 =200, n2 =30;
		System.out.println(work3Math.add(n1, n2));
		System.out.println(work3Math.subtract(n1, n2));
		System.out.println(work3Math.multiply(n1, n2));
		System.out.println(work3Math.divide(n1, n2));
		
	}

}
