package day7;

public class WorkGameDemo {

	public static void main(String[] args) {
		Work2Game work2Game = new Work2Game();
		work2Game.startGame();

	}

}
