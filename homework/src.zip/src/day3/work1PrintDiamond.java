package day3;
/**
 * ����1 ��ӡ����
 * @author Administrator
 *
 */

public class work1PrintDiamond {

	public static void main(String[] args) {
		for(int i=1; i<=9; i++)
		{
			for(int j=1; j<=9; j++)
			{
				
			}
		}

	}

}
