package day5;

public class PlayerDemo {

	public static void main(String[] args) {
		Player player = new Player();
		player.age = 200;
		player.name="dfdfdf";
		
		player.showInfo();

	}

}
